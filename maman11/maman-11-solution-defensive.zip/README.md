# MAMAN 11 question 3:

### In order to run this solution on Windows:
* Open `Visual studio`
* Add support/plugin for `cmake`
* run `cmake` on project `CMakeList.txt` file.
* compile & run

#### Enjoy reading.

---
Written By: `Hagai Vinik` <br>
Date: `24/11/2022`