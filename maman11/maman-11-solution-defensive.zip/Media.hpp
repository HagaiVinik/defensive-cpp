//
// Created by hagaivinik on 11/22/22.
//

#ifndef MAMAN11_MEDIA_HPP
#define MAMAN11_MEDIA_HPP


class Media
{
public:
    virtual void display() = 0;
};


#endif //MAMAN11_MEDIA_HPP
